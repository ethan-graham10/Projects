import java.sql.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/* Online fulfilment of grocery stores. so make a grocery store 
 * Do the trucks coming in and filling the grocery store. 
 * Do the user side where they are ordering the food they want and then it gets picked up. 
 * 
 * https://docs.oracle.com/javase/tutorial/jdbc/basics/processingsqlstatements.html
 * https://docs.oracle.com/javase/tutorial/jdbc/basics/gettingstarted.html
 * https://docs.oracle.com/javase/tutorial/jdbc/basics/retrieving.html
 * https://www.codejava.net/coding/how-to-read-excel-files-in-java-using-apache-poi
 */
public class main {
	public static void main(String[] args) {
		String excelFilePath = ("H:\\Java_project\\product_list.xlsx");
		FileInputStream inputStream;
		Connection conn1 = null;
		try {
			
			//for database
			Class.forName("oracle.jdbc.OracleDriver");
			String dbURL1 = "jdbc:oracle:thin:trainee1/!QAZSE4@localhost:1521:xe";
            conn1 = DriverManager.getConnection(dbURL1);
            if (conn1 != null) {
                System.out.println("Connected with connection #1");
            }
            
            
            //read in excel file variables
			inputStream = new FileInputStream(new File(excelFilePath));
	        Workbook workbook = new XSSFWorkbook(inputStream);
	        Sheet firstSheet = workbook.getSheetAt(0);
	        Iterator<Row> iterator = firstSheet.iterator();
	        
	        //table variables
	        ArrayList<String> columnNames = new ArrayList<String>();
	        Boolean isTitleRow = true; 
	        String createTableString = "create table PRODUCTS (";
	        
	        
	        //read in excel file and create variables
	        while (iterator.hasNext()) {
	            Row nextRow = iterator.next();
	            Iterator<Cell> cellIterator = nextRow.cellIterator();
	             
	            while (cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	                 
	                if (isTitleRow) {
	                	columnNames.add(cell.getStringCellValue()); //gets first row
	                	
	                }
	                
	                else { //still have to deal with rest of data in string.
		                switch (cell.getCellType()) { 
		                    case Cell.CELL_TYPE_STRING: 
		                        System.out.print(cell.getStringCellValue());
		                        break;
		                    case Cell.CELL_TYPE_BOOLEAN:
		                        System.out.print(cell.getBooleanCellValue());
		                        break;
		                    case Cell.CELL_TYPE_NUMERIC:
		                        System.out.print(cell.getNumericCellValue());
		                        break;
		                }
		                System.out.print(" - ");
	                }
	                
	            }
	            if(isTitleRow) {
	            	for (int ii = 0; ii < columnNames.size(); ii++) 
	            		createTableString += columnNames.get(ii) + " varchar2(40), ";
	            	createTableString = createTableString.substring(0,createTableString.length()-2) 
	            			+ ")";
	            	System.out.println(createTableString);
	            }
	            
	            isTitleRow = false;
	            System.out.println();
	        }
	        
	        
	        //create table, check table has been created
	        Statement stmt = conn1.createStatement();
	        String dropString = "drop table PRODUCTS";
	        stmt.executeUpdate(dropString);
	        stmt.executeUpdate(createTableString);
	        stmt.executeUpdate("insert into PRODUCTS " +
                    "values('yes', 'table', 'created')");
	        
	        String query = "SELECT productid "
					+ "from PRODUCTS ";
	        ResultSet rs = stmt.executeQuery(query);
	        while (rs.next()) {
		    	 String productId = rs.getString("PRODUCTID");
		         //String streetName = rs.getString("STREET");
		         
		         System.out.println(productId + "\t");
		     }
	        
	        /*for (String ii : columnNames) {
	        	System.out.println(ii);
	        }*/
	        
	        /*
	        while (iterator.hasNext()) {
	            Row nextRow = iterator.next();
	            Iterator<Cell> cellIterator = nextRow.cellIterator();
	             
	            while (cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	                 
	                switch (cell.getCellType()) {
	                    case Cell.CELL_TYPE_STRING:
	                        System.out.print(cell.getStringCellValue());
	                        break;
	                    case Cell.CELL_TYPE_BOOLEAN:
	                        System.out.print(cell.getBooleanCellValue());
	                        break;
	                    case Cell.CELL_TYPE_NUMERIC:
	                        System.out.print(cell.getNumericCellValue());
	                        break;
	                }
	                System.out.print(" - ");
	            }
	            System.out.println();
	        } */
	         
	        workbook.close();
	        inputStream.close();
	        
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}        
		
		/*
		Connection conn1 = null;
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			String dbURL1 = "jdbc:oracle:thin:trainee1/!QAZSE4@localhost:1521:xe";
            conn1 = DriverManager.getConnection(dbURL1);
            if (conn1 != null) {
                System.out.println("Connected with connection #1");
            }
	        
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		
		

	}
}
