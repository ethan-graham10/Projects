import java.sql.*;

public class the_hub {
	public static void main(String[] args) {
		Connection conn1 = null;
		String query = "SELECT STREET, SUP_ID, SUP_NAME, "
						+ "CITY, STATE from suppliers ";
		String dropString = "drop table SUPPLIERS";
		String createString =
			      "create table SUPPLIERS " + "(SUP_ID integer NOT NULL, " +
			      "SUP_NAME varchar(40) NOT NULL, " + "STREET varchar(40) NOT NULL, " +
			      "CITY varchar(20) NOT NULL, " + "STATE char(2) NOT NULL, " +
			      "ZIP char(5), " + "PRIMARY KEY (SUP_ID))";
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			
			String dbURL1 = "jdbc:oracle:thin:trainee1/!QAZSE4@localhost:1521:xe";
            conn1 = DriverManager.getConnection(dbURL1);
	            if (conn1 != null) {
	                System.out.println("Connected with connection #1");
	            }
		
            System.out.println("here");
            
            Statement stmt = conn1.createStatement();
           //ResultSet rs = stmt.executeQuery(query);
            stmt.executeUpdate(dropString);
            stmt.executeUpdate(createString);

            stmt.executeUpdate("insert into SUPPLIERS " +
                    "values(49, 'Superior Coffee', '1 Party Place', " +
                    "'Mendocino', 'CA', '95460')");
            stmt.executeUpdate("insert into SUPPLIERS " +
                    "values(101, 'Acme, Inc.', '99 Market Street', " +
                    "'Groundsville', 'CA', '95199')");
            stmt.executeUpdate("insert into SUPPLIERS " +
                    "values(150, 'The High Ground', '100 Coffee Lane', " +
                    "'Meadows', 'CA', '93966')");
            stmt.executeUpdate("insert into SUPPLIERS " +
                    "values(129, 'Acme, Inc.', '99 Market Street', " +
                    "'Groundsville', 'CA', '95199')");
            ResultSet rs = stmt.executeQuery(query);
		     while (rs.next()) {
		    	 int supplierId = rs.getInt("SUP_ID");
		    	 String supplierName = rs.getString("SUP_NAME");
		    	 String supplierCity = rs.getString("CITY");
		    	 String supplierState = rs.getString("STATE");
		         //String streetName = rs.getString("STREET");
		         
		         System.out.println(supplierId + "\t" + supplierName + "\t" +
		        		 			supplierCity + "\t" + supplierState);
		     }
		
		}  catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
